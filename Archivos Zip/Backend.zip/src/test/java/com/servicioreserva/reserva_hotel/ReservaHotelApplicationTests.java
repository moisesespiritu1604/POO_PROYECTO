package com.servicioreserva.reserva_hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservaHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
