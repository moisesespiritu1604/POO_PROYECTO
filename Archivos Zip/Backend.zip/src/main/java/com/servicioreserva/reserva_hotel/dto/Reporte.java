package com.servicioreserva.reserva_hotel.dto;

public class Reporte {
    
}
