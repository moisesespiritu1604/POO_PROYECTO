package com.servicioreserva.reserva_hotel.dto;

import lombok.Data;

@Data
public class ImagenHotel {
    private Hotel hotel;
    private String url;
}
