package com.servicioreserva.reserva_hotel.dto;

import java.util.List;

import lombok.Data;
@Data
public class RespuestaHotel {
    private List<Hotel> lista;
}
