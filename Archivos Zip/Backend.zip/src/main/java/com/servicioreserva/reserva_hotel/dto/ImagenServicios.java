package com.servicioreserva.reserva_hotel.dto;

import lombok.Data;

@Data
public class ImagenServicios {
    private Servicios servicios;
    private String url;
}
